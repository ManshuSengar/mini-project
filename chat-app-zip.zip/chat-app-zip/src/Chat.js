// import React, { useEffect, useState } from "react";
// import axios from "axios";
// import socket from "./socket";
// import {
//   Box,
//   TextField,
//   Button,
//   Typography,
//   List,
//   ListItem,
//   ListItemText,
//   ListItemAvatar,
//   Avatar,
//   IconButton,
//   Paper,
// } from "@mui/material";
// import {
//   Send as SendIcon,
//   AttachFile as AttachFileIcon,
// } from "@mui/icons-material";

// const Chat = ({ user, userToken }) => {
//   const [chats, setChats] = useState([]);
//   const [messages, setMessages] = useState([]);
//   const [selectedChat, setSelectedChat] = useState(null);
//   const [newMessage, setNewMessage] = useState("");
//   const [file, setFile] = useState(null);
//   const [onlineUsers, setOnlineUsers] = useState({});

//   useEffect(() => {
//     socket.emit("init_user", user.id);

//     socket.on("new_msg_received", (msg) => {
//       if (selectedChat && msg.chat._id === selectedChat._id) {
//         setMessages((prev) => [...prev, msg]);
//       }
//     });

//     socket.on("getUserOnline", ({ userId }) => {
//       setOnlineUsers((prev) => ({ ...prev, [userId]: true }));
//     });

//     socket.on("getUserOffline", ({ userId }) => {
//       setOnlineUsers((prev) => ({ ...prev, [userId]: false }));
//     });

//     return () => {
//       socket.off("new_msg_received");
//       socket.off("getUserOnline");
//       socket.off("getUserOffline");
//     };
//   }, [selectedChat, user]);

//   useEffect(() => {
//     const fetchChats = async () => {
//       try {
//         const response = await axios.get("http://localhost:8080/api/chat", {
//           headers: {
//             Authorization: `Bearer ${userToken}`,
//           },
//         });
//         setChats(response.data);

//         const initialOnlineStatus = {};
//         console.log("response--> ", response.data);
//         response.data.forEach((chat) => {
//           chat.users.forEach((u) => {
//             console.log("user--> ", u);
//             if (u.id !== user.id) {
//               console.log(
//                 "initialOnlineStatus[u.id] = u.online || false;",
//                 (initialOnlineStatus[u.id] = u.online || false)
//               );
//               initialOnlineStatus[u.id] = u.online || false;
//             }
//           });
//         });
//         setOnlineUsers(initialOnlineStatus);
//       } catch (error) {
//         console.error(error);
//       }
//     };

//     fetchChats();
//   }, [userToken, user.id]);

//   const fetchMessages = async (chatId) => {
//     try {
//       const response = await axios.get(
//         `http://localhost:8080/api/message/${chatId}`,
//         {
//           headers: {
//             Authorization: `Bearer ${userToken}`,
//           },
//         }
//       );
//       setMessages(response.data);
//     } catch (error) {
//       console.error(error);
//     }
//   };

//   const sendMessage = async () => {
//     if (!newMessage.trim() && !file) return;
//     try {
//       const chatId = selectedChat._id;

//       const formData = new FormData();
//       formData.append("content", newMessage);
//       formData.append("chatId", chatId);
//       if (file) {
//         formData.append("file", file);
//         setFile(null);
//       }

//       const response = await axios.post(
//         "http://localhost:8080/api/message",
//         formData,
//         {
//           headers: {
//             Authorization: `Bearer ${userToken}`,
//             "Content-Type": "multipart/form-data",
//           },
//         }
//       );

//       socket.emit("new_msg_sent", response.data);
//       setMessages((prev) => [...prev, response.data]);
//       setNewMessage("");
//     } catch (error) {
//       console.error(error);
//     }
//   };

//   const renderMessageContent = (message) => {
//     if (message.file) {
//       if (message.file.mimetype.startsWith("image")) {
//         return (
//           <img
//             src={message.file.url}
//             alt="Sent image"
//             style={{ maxWidth: "200px", maxHeight: "200px" }}
//           />
//         );
//       } else {
//         return (
//           <a href={message.file.url} target="_blank" rel="noopener noreferrer">
//             {message.file.originalname}
//           </a>
//         );
//       }
//     }
//     return message.content;
//   };

//   return (
//     <Box display="flex" height="100vh">
//       <Paper elevation={3} sx={{ width: "30%", overflow: "auto" }}>
//         <Typography variant="h6" p={2}>
//           Chats
//         </Typography>
//         <List>
//           {chats.map((chat) => {
//             const otherUser = chat.users.find((u) => u.id !== user.id);
//             {
//               console.log("otherUser--> ", otherUser);
//             }
//             return (
//               <ListItem
//                 key={chat._id}
//                 button
//                 onClick={() => {
//                   setSelectedChat(chat);
//                   fetchMessages(chat._id);
//                 }}
//                 selected={selectedChat && selectedChat._id === chat._id}
//               >
//                 {console.log("otherUser-_>", otherUser)}
//                 <ListItemAvatar>
//                   <Avatar src={otherUser.avatar || ""} />
//                 </ListItemAvatar>
//                 <ListItemText
//                   primary={otherUser.email || otherUser.email}
//                   secondary={onlineUsers[otherUser.id] ? "Online" : "Offline"}
//                 />
//               </ListItem>
//             );
//           })}
//         </List>
//       </Paper>
//       <Box flexGrow={1} display="flex" flexDirection="column" p={2}>
//         {selectedChat ? (
//           <>
//             <Paper
//               elevation={3}
//               sx={{ flexGrow: 1, overflow: "auto", mb: 2, p: 2 }}
//             >
//               <List>
//                 {messages.map((msg) => (
//                   <ListItem key={msg._id} alignItems="flex-start">
//                     <ListItemAvatar>
//                       <Avatar src={msg.sender.avatar || ""} />
//                     </ListItemAvatar>
//                     <ListItemText
//                       primary={renderMessageContent(msg)}
//                       secondary={
//                         msg.sender._id === user.id ? "You" : msg.sender.name
//                       }
//                     />
//                   </ListItem>
//                 ))}
//               </List>
//             </Paper>
//             <Box display="flex">
//               <TextField
//                 variant="outlined"
//                 fullWidth
//                 placeholder="Type a message"
//                 value={newMessage}
//                 onChange={(e) => setNewMessage(e.target.value)}
//                 onKeyPress={(e) => e.key === "Enter" && sendMessage()}
//               />
//               <input
//                 type="file"
//                 onChange={(e) => setFile(e.target.files[0])}
//                 style={{ display: "none" }}
//                 id="file-input"
//               />
//               <label htmlFor="file-input">
//                 <IconButton component="span">
//                   <AttachFileIcon />
//                 </IconButton>
//               </label>
//               <Button variant="contained" color="primary" onClick={sendMessage}>
//                 <SendIcon />
//               </Button>
//             </Box>
//           </>
//         ) : (
//           <Typography variant="h6" align="center">
//             Select a chat to start messaging
//           </Typography>
//         )}
//       </Box>
//     </Box>
//   );
// };

// export default Chat;

import React, { useEffect, useState } from "react";
import axios from "axios";
import socket from "./socket";
import {
  Box,
  TextField,
  Button,
  Typography,
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  Avatar,
  IconButton,
  Paper,
} from "@mui/material";
import {
  Send as SendIcon,
  AttachFile as AttachFileIcon,
  Close as CloseIcon,
} from "@mui/icons-material";

const Chat = ({ user, userToken }) => {
  const [chats, setChats] = useState([]);
  const [messages, setMessages] = useState([]);
  const [selectedChat, setSelectedChat] = useState(null);
  const [newMessage, setNewMessage] = useState("");
  const [file, setFile] = useState(null);
  const [onlineUsers, setOnlineUsers] = useState({});
  const [filePreview, setFilePreview] = useState(null);

  useEffect(() => {
    socket.emit("init_user", user.id);

    socket.on("new_msg_received", (msg) => {
      if (selectedChat && msg.chat._id === selectedChat._id) {
        setMessages((prev) => [...prev, msg]);
      }
    });

    socket.on("getUserOnline", ({ userId }) => {
      setOnlineUsers((prev) => ({ ...prev, [userId]: true }));
    });

    socket.on("getUserOffline", ({ userId }) => {
      setOnlineUsers((prev) => ({ ...prev, [userId]: false }));
    });

    return () => {
      socket.off("new_msg_received");
      socket.off("getUserOnline");
      socket.off("getUserOffline");
    };
  }, [selectedChat, user]);

  useEffect(() => {
    const fetchChats = async () => {
      try {
        const response = await axios.get("http://localhost:8080/api/chat", {
          headers: {
            Authorization: `Bearer ${userToken}`,
          },
        });
        setChats(response.data);

        const initialOnlineStatus = {};
        response.data.forEach((chat) => {
          chat.users.forEach((u) => {
            if (u.id !== user.id) {
              initialOnlineStatus[u.id] = u.online || false;
            }
          });
        });
        setOnlineUsers(initialOnlineStatus);
      } catch (error) {
        console.error(error);
      }
    };

    fetchChats();
  }, [userToken, user.id]);

  const fetchMessages = async (chatId) => {
    try {
      const response = await axios.get(
        `http://localhost:8080/api/message/${chatId}`,
        {
          headers: {
            Authorization: `Bearer ${userToken}`,
          },
        }
      );
      setMessages(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    setFile(selectedFile);

    if (selectedFile) {
      if (selectedFile.type.startsWith("image/")) {
        const reader = new FileReader();
        reader.onload = (e) => setFilePreview(e.target.result);
        reader.readAsDataURL(selectedFile);
      } else {
        setFilePreview(selectedFile.name);
      }
    } else {
      setFilePreview(null);
    }
  };

  const clearFileSelection = () => {
    setFile(null);
    setFilePreview(null);
  };

  const sendMessage = async () => {
    if (!newMessage.trim() && !file) return;
    try {
      const chatId = selectedChat._id;

      const formData = new FormData();
      formData.append("content", newMessage);
      formData.append("chatId", chatId);
      if (file) {
        formData.append("file", file);
      }

      const response = await axios.post(
        "http://localhost:8080/api/message",
        formData,
        {
          headers: {
            Authorization: `Bearer ${userToken}`,
            "Content-Type": "multipart/form-data",
          },
        }
      );

      socket.emit("new_msg_sent", response.data);
      setMessages((prev) => [...prev, response.data]);
      setNewMessage("");
      clearFileSelection();
    } catch (error) {
      console.error(error);
    }
  };

  const renderMessageContent = (message) => {
    if (message.fileUrl) {
      return (
        <img
          src={message.fileUrl}
          alt="Sent image"
          style={{ maxWidth: "200px", maxHeight: "200px" }}
        />
      );
    }
    return message.content;
  };

  return (
    <Box display="flex" height="100vh">
      <Paper elevation={3} sx={{ width: "30%", overflow: "auto" }}>
        <Typography variant="h6" p={2}>
          Chats
        </Typography>
        <List>
          {chats.map((chat) => {
            const otherUser = chat.users.find((u) => u.id !== user.id);
            return (
              <ListItem
                key={chat._id}
                button
                onClick={() => {
                  setSelectedChat(chat);
                  fetchMessages(chat._id);
                }}
                selected={selectedChat && selectedChat._id === chat._id}
              >
                <ListItemAvatar>
                  <Avatar src={otherUser.avatar || ""} />
                </ListItemAvatar>
                <ListItemText
                  primary={otherUser.email || otherUser.email}
                  secondary={onlineUsers[otherUser.id] ? "Online" : "Offline"}
                />
              </ListItem>
            );
          })}
        </List>
      </Paper>
      <Box flexGrow={1} display="flex" flexDirection="column" p={2}>
        {selectedChat ? (
          <>
            <Paper
              elevation={3}
              sx={{ flexGrow: 1, overflow: "auto", mb: 2, p: 2 }}
            >
              <List>
                {messages.map((msg) => (
                  <ListItem key={msg._id} alignItems="flex-start">
                    <ListItemAvatar>
                      <Avatar src={msg.sender.avatar || ""} />
                    </ListItemAvatar>
                    <ListItemText
                      primary={renderMessageContent(msg)}
                      secondary={
                        msg.sender.id === user.id ? "You" : msg.sender.email
                      }
                    />
                  </ListItem>
                ))}
              </List>
            </Paper>
            <Box display="flex" flexDirection="column">
              {filePreview && (
                <Box mb={1} display="flex" alignItems="center">
                  {typeof filePreview === "string" ? (
                    <Typography>{filePreview}</Typography>
                  ) : (
                    <img
                      src={filePreview}
                      alt="Preview"
                      style={{ maxWidth: "100px", maxHeight: "100px" }}
                    />
                  )}
                  <IconButton onClick={clearFileSelection} size="small">
                    <CloseIcon />
                  </IconButton>
                </Box>
              )}
              <Box display="flex">
                <TextField
                  variant="outlined"
                  fullWidth
                  placeholder="Type a message"
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && sendMessage()}
                />
                <input
                  type="file"
                  onChange={handleFileChange}
                  style={{ display: "none" }}
                  id="file-input"
                />
                <label htmlFor="file-input">
                  <IconButton component="span">
                    <AttachFileIcon />
                  </IconButton>
                </label>
                <Button
                  variant="contained"
                  color="primary"
                  onClick={sendMessage}
                >
                  <SendIcon />
                </Button>
              </Box>
            </Box>
          </>
        ) : (
          <Typography variant="h6" align="center">
            Select a chat to start messaging
          </Typography>
        )}
      </Box>
    </Box>
  );
};

export default Chat;
